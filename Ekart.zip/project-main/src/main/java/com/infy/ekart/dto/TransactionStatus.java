package com.infy.ekart.dto;

public enum TransactionStatus {
TRANSACTION_SUCCESS , TRANSACTION_FAILED
}
