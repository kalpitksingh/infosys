package com.infy.ekart.service.test;

import static org.mockito.ArgumentMatchers.any;

import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.infy.ekart.dto.CustomerDTO;
import com.infy.ekart.entity.Customer;
import com.infy.ekart.exception.EKartException;
import com.infy.ekart.repository.CustomerRepository;
import com.infy.ekart.service.CustomerService;
import com.infy.ekart.service.CustomerServiceImpl;

@SpringBootTest
public class CustomerServiceTest {
	// Write testcases here
	@Mock
	private CustomerRepository customerRepository;

	@InjectMocks
	CustomerService customerService = new CustomerServiceImpl();

	@Test
	void authenticateCustomerValidTest() throws EKartException {
		Customer customer = new Customer();
		customer.setEmailId("john@infosys.com");
		customer.setPassword("John@123");

		String emailId = "john@infosys.com";
		String password = "John@123";
		Mockito.when(customerRepository.findById(Mockito.anyString())).thenReturn(Optional.of(customer));
		CustomerDTO customerDTO = customerService.authenticateCustomer(emailId, password);
		Assertions.assertEquals(customer.getEmailId(), customerDTO.getEmailId());
	}

	@Test
	void authenticateCustomerInvalidTest1() throws EKartException {
		String emailId = "john@infosys.com";
		String password = "John@123";
		Mockito.when(customerRepository.findById(Mockito.anyString().toLowerCase())).thenReturn(Optional.empty());
		Exception exception = Assertions.assertThrows(EKartException.class,
				() -> customerService.authenticateCustomer(emailId, password));
		Assertions.assertEquals("CustomerService.CUSTOMER_NOT_FOUND", exception.getMessage());
	}

	@Test
	void authenticateCustomerInvalidTest2() throws EKartException {
		Customer customer = new Customer();
		customer.setEmailId("john@infosys.com");
		customer.setPassword("John@123");

		String emailId = "harry@infosys.com";
		String password = "Harry@123";
		Mockito.when(customerRepository.findById(Mockito.anyString().toLowerCase())).thenReturn(Optional.of(customer));
		Exception exception = Assertions.assertThrows(EKartException.class,
				() -> customerService.authenticateCustomer(emailId, password));
		Assertions.assertEquals("CustomerService.INVALID_CREDENTIALS", exception.getMessage());
	}

	@Test
	void registerNewCustomerValidTest() throws EKartException {
		Customer customer = new Customer();
		customer.setEmailId("sam@infosys.com");
		customer.setPassword("sam@123");
		customer.setAddress("abc");
		customer.setPhoneNumber("8767676788");
		customer.setName("Sam");
		
		CustomerDTO customerDTO = new CustomerDTO();
		customerDTO.setPhoneNumber("8767676767");
		customerDTO.setEmailId("sam@infosys.com");
		customerDTO.setAddress("abc");
		customerDTO.setName("Sam");
		customerDTO.setPassword("Sam@123");

		Mockito.when(customerRepository.findById(customerDTO.getEmailId())).thenReturn(Optional.empty());
		Mockito.when(customerRepository.findByPhoneNumber(customerDTO.getPhoneNumber())).thenReturn(null);
		Mockito.when(customerRepository.save(any())).thenReturn(customer);
		Assertions.assertEquals(customer.getEmailId(), customerService.registerNewCustomer(customerDTO));
		
	}

	@Test
	void registerNewCustomerInvalidTest1() throws EKartException {
		Customer customer = new Customer();
		customer.setEmailId("sam@infosys.com");
		customer.setPassword("Sam@123");
		customer.setAddress("abc");
		customer.setPhoneNumber("8767676767");
		customer.setName("Sam");

		CustomerDTO customerDTO = new CustomerDTO();
		customerDTO.setPhoneNumber("8767676767");
		customerDTO.setEmailId("sam@infosys.com");
		customerDTO.setAddress("abc");
		customerDTO.setName("Sam");
		customerDTO.setPassword("Sam@123");

		Mockito.when(customerRepository.findById(customerDTO.getEmailId())).thenReturn(Optional.of(customer));
		Mockito.when(customerRepository.findByPhoneNumber(customerDTO.getPhoneNumber()))
				.thenReturn(Boolean.TRUE.toString());

		EKartException exception = Assertions.assertThrows(EKartException.class,
				() -> customerService.registerNewCustomer(customerDTO));
		Assertions.assertEquals("CustomerService.EMAIL_ID_ALREADY_IN_USE", exception.getMessage());
	}

	@Test
	void registerNewCustomerInvalidTest2() throws EKartException {
		Customer customer = new Customer();
		customer.setEmailId("sam@infosys.com");
		customer.setPassword("Sam@123");
		customer.setAddress("abc");
		customer.setPhoneNumber("8767676767");
		customer.setName("Sam");

		CustomerDTO customerDTO = new CustomerDTO();
		customerDTO.setPhoneNumber("8767676767");
		customerDTO.setEmailId("sam@infosys.com");
		customerDTO.setAddress("abc");
		customerDTO.setName("Sam");
		customerDTO.setPassword("Sam@123");

		Mockito.when(customerRepository.findById(customerDTO.getEmailId())).thenReturn(Optional.empty());
		Mockito.when(customerRepository.findByPhoneNumber(customerDTO.getPhoneNumber()))
				.thenReturn(Boolean.FALSE.toString());

		EKartException exception = Assertions.assertThrows(EKartException.class,
				() -> customerService.registerNewCustomer(customerDTO));
		Assertions.assertEquals("CustomerService.PHONE_NUMBER_ALREADY_IN_USE", exception.getMessage());
	}

	@Test
	void updateShippingAddressValidTest() throws EKartException {
		Customer customer = new Customer();
		customer.setEmailId("sam@infosys.com");
		customer.setPassword("Sam@123");
		customer.setAddress("abc");
		customer.setPhoneNumber("8767676767");
		customer.setName("Sam");

		Mockito.when(customerRepository.findById(Mockito.anyString())).thenReturn(Optional.of(customer));
		customerService.updateShippingAddress(customer.getEmailId(), "xyz");
		Assertions.assertEquals("xyz", customer.getAddress());
	}

	@Test
	void updateShippingAddressInvalidTest() throws EKartException {
		Customer customer = new Customer();
		customer.setEmailId("sam@infosys.com");
		customer.setPassword("Sam@123");
		customer.setAddress("abc");
		customer.setPhoneNumber("8767676767");
		customer.setName("Sam");

		Mockito.when(customerRepository.findById(Mockito.anyString())).thenReturn(Optional.empty());
		EKartException exception = Assertions.assertThrows(EKartException.class,
				() -> customerService.updateShippingAddress(customer.getEmailId(), customer.getAddress()));
		Assertions.assertEquals("CustomerService.CUSTOMER_NOT_FOUND", exception.getMessage());

	}

	@Test
	void deleteShippingAddressValidTest() throws EKartException {
		Customer customer = new Customer();
		customer.setEmailId("sam@infosys.com");
		customer.setPassword("Sam@123");
		customer.setAddress("abc");
		customer.setPhoneNumber("8767676767");
		customer.setName("Sam");

		Mockito.when(customerRepository.findById(Mockito.anyString())).thenReturn(Optional.of(customer));
		customerService.deleteShippingAddress(customer.getEmailId());
		Assertions.assertNull(customer.getAddress());
	}

	@Test
	void deleteShippingAddressInvalidTest() throws EKartException {
		Customer customer = new Customer();
		customer.setEmailId("sam@infosys.com");
		customer.setPassword("Sam@123");
		customer.setAddress("abc");
		customer.setPhoneNumber("8767676767");
		customer.setName("Sam");

		Mockito.when(customerRepository.findById(Mockito.anyString())).thenReturn(Optional.empty());
		EKartException exception = Assertions.assertThrows(EKartException.class,
				() -> customerService.deleteShippingAddress(customer.getAddress()));
		Assertions.assertEquals("CustomerService.CUSTOMER_NOT_FOUND", exception.getMessage());
	}

	@Test
	void getCustomerByEmailIdValidTest() throws EKartException {
		Customer customer = new Customer();
		customer.setEmailId("sam@infosys.com");
		customer.setPassword("Sam@123");
		customer.setAddress("abc");
		customer.setPhoneNumber("8767676767");
		customer.setName("Sam");

		CustomerDTO customerDTO = new CustomerDTO();
		customerDTO.setPhoneNumber("8767676767");
		customerDTO.setEmailId("sam@infosys.com");
		customerDTO.setAddress("abc");
		customerDTO.setName("Sam");
		customerDTO.setPassword("Sam@123");

		Mockito.when(customerRepository.findById(Mockito.anyString())).thenReturn(Optional.of(customer));
		Assertions.assertEquals(customerDTO.getEmailId(),
				customerService.getCustomerByEmailId(customer.getEmailId()).getEmailId());
	}

	@Test
	void getCustomerByEmailIdInvalidTest() throws EKartException {
		Customer customer = new Customer();
		customer.setEmailId("sam@infosys.com");
		customer.setPassword("Sam@123");
		customer.setAddress("abc");
		customer.setPhoneNumber("8767676767");
		customer.setName("Sam");

		Mockito.when(customerRepository.findById(Mockito.anyString())).thenReturn(Optional.empty());
		EKartException exception = Assertions.assertThrows(EKartException.class,
				() -> customerService.getCustomerByEmailId(customer.getEmailId()));
		Assertions.assertEquals("CustomerService.CUSTOMER_NOT_FOUND", exception.getMessage());
	}
}
